
import streamlit as st
import pandas as pd
import altair as alt
import plotly.graph_objs as go
from collections import Counter
import re
import matplotlib.pyplot as plt
import  seaborn as sns
import plotly.express as px
import  base64
from plotly.data import gapminder
from altair.vegalite.v3.api import Chart

main_bg = "img/fundo2.png"
main_bg_ext = "img/fundo2.png"

side_bg = "img/logo2.png"
side_bg_ext = "img/logo2.png"


st.markdown(
    f"""
    <style>

    .reportview-container {{
        background: url(data:image/{main_bg_ext};base64,{base64.b64encode(open(main_bg, "rb").read()).decode()})

    
    }}
    
    .reportview-container .markdown-text-container {{
      font-family: calibri;
      color: white;
    }}
    
    .sidebar .sidebar-content {{
      
      background-image: linear-gradient(#b38fb5,#b38fb5);
      color: black; 

      ## background: url(data:image/{side_bg_ext};base64,{base64.b64encode(open(side_bg, "rb").read()).decode()}) ##
    
      ## background: url("img/logo2.jpg") ##
      
    }}

   .Widget>label {{
     color: white;
     font-family: calibri;
   }}

   [class^="st-b"]  {{
     color: white;
     font-family: calibri;
   }}
   
   .st-bb {{
     background-color: green;

   }}

   .st-at {{
     background-color: black;
   }}
  
 

   .reportview-container .main footer, .reportview-container .main footer a {{
    color: #0c0080;
   }}

   header .decoration {{
     background - image:none;
   }}
   
    </style>
    """,
    unsafe_allow_html=True
)



def criar_barras(coluna_num, coluna_cat, df):
    bars = alt.Chart(df, width = 600).mark_circle().encode(
        x=alt.X(coluna_num, stack='zero'),
        y=alt.Y(coluna_cat),
        tooltip=[coluna_cat, coluna_num]
    ).interactive()
    return bars

def criar_scatterplot(x, y, color, df):
    scatter = alt.Chart(df, width=800, height=400).mark_circle().encode(
        alt.X(x),
        alt.Y(y),
        color = color,
        tooltip = [x, y]
    ).interactive()
    return scatter

def cria_correlationplot(df, colunas_numericas):
    cor_data = (df[colunas_numericas]).corr().stack().reset_index().rename(columns={0: 'correlation', 'level_0': 'variable', 'level_1': 'variable2'})
    cor_data['correlation_label'] = cor_data['correlation'].map('{:.2f}'.format)  # Round to 2 decimal
    base = alt.Chart(cor_data, width=500, height=500).encode( x = 'variable2:O', y = 'variable:O')
    text = base.mark_text().encode(text = 'correlation_label',color = alt.condition(alt.datum.correlation > 0.5,alt.value('white'),
    alt.value('black')))

    cor_plot = base.mark_rect().encode(color='correlation:Q')
    return cor_plot + text


# Sidebar principal
def menu():
    st.sidebar.header('**Menu Inicial**')
    page = st.sidebar.radio("", ('Sobre',
                                'Análise de Dados dos álbuns'))
    if page == 'Sobre':
        sobre()
    if page == 'Análise de Dados dos álbuns':
        analise_nexoanexo()


## Páginas principais ## --------------------------------------------------------------------------------


# Sobre o Projeto
def sobre():
    # Sobre o Projeto
    st.title('Spotify + Python + Pearl Jam')
    '''
    
    '''
    '''
    Essa é uma aplicação publicada no Heroku do projeto de análise dos dados com Python dos álbuns da banda Pearl Jam no Spotify. 
   
    O objetivo da aplicação é extrair insights a partir dos dados e verificar quais as músicas foram as mais populares no Brasil em novembro de 2020.

    
    '''
   #O Artista
    st.title('banda Pearl Jam')
    st.image('img/logo.jpg', width=200)
    '''
    Pearl Jam é uma banda norte-americana de rock alternativo, formada no ano de 1990 em Seattle, Washington. Desde sua origem, é formada por Eddie Vedder, Jeff Ament, Stone Gossard e Mike McCready, passando por mudanças na bateria, sendo Matt Cameron, que também compõe o Soundgarden,o atual baterista da banda. O Allmusic se refere ao Pearl Jam como "a banda americana de rock & roll mais popular dos anos 90." O Pearl Jam foi incluído no Rock and Roll Hall of Fame em 2017. 
    Em 27-03-20 a banda lançou seu décimo primeiro álbum Gigaton. Este é o primeiro álbum em sete anos, o anterior foi Lightning Bolt em 2013. (Fonte: Wikipédia)
    '''
    ''' 
    `Eddie Vedder`: vocalista

    `Mike McCready`: guitarra solo

    `Jeff Ament`: baixo elétrico

    `Stone Gossard`: guitarra
    
    `Matt Cameron`: bateria

    `Boom Gaspar`: teclado
    '''
    '''
    '''
   # Informações
    st.title('API Spotify & Python')

    '''
    

Ê possível extrair via API os dados e a popularidade de uma música de acordo com as métricas do Spotify.
A popularidade é calculada também a partir do número total de reproduções que a faixa teve naquele intervalo de tempo. As músicas que estão sendo tocadas com maior frequência atualmente terão uma popularidade maior do que as músicas que foram muito tocadas no passado.

Como a popularidade das músicas pode alterar diariamente, utilizei o recorte do dia 05-11-20 com as músicas reproduzidas no Brasil e limitei aos nove álbuns mais recentes da banda. 

O Spotify também disponibiliza o Spotify Charts e permite acompanhar as músicas TOP e virais: https://spotifycharts.com/regional    

   
    '''

    st.title('Álbum e Músicas coletadas')

    st.title("**Álbum Gigaton** 2020")
    st.video("https://www.youtube.com/watch?v=fYSazphh_C8&list=PLbHEWFpV0NSs1j_UPOsERpV7Va4MvIcVP&index=2")

    st.title('**Vault 9: Live in Seattle 12/8/93** 2019')
    st.video('https://www.youtube.com/watch?v=jyRYOf5hVck&list=OLAK5uy_mkKl-yAvGlM3SdDUOWiQL5rcpJB4baho0')

    st.title('**Lets Play Two** 2017')
    st.video('https://www.youtube.com/watch?v=kYQXDwVjhKs&list=PLi_9g3NzCdCalh3gdwpPW6HASdSCUZ5ER&index=2')

    st.title('**Pearl Jam** Mix 2017')
    st.video('https://www.youtube.com/watch?v=4OVU0fN2XJw&list=PL0xXGZWysIyaWC5FXZBHfB75XJpBqPeL5')

    st.title('**Lightning Bolt** 2013')
    st.video('https://www.youtube.com/watch?v=TbTiOCIa5zY&list=OLAK5uy_klinpO9cMEFPebjTdmITYpbQUVvZ4OOjU&index=5')

    st.title('**Backspacer** 2009')
    st.video('https://www.youtube.com/watch?v=_7ioE4wRil8&list=OLAK5uy_mFzQCIeLRHTQG3fmbcfrTJ0jRf5Lywf6U&index=5')

    st.title('**Pearl Jam** 2006')
    st.video('https://www.youtube.com/watch?v=kytfNFwQ04s')

    st.title('**Riot Act** 2002')
    st.video('https://www.youtube.com/watch?v=_2EQuWYpq80&list=OLAK5uy_mlnL-q5XG1DE-Sft7fFtQg-6LPE8VQl1s&index=1')

    st.title('**Live MTV Unplugged** 1992')
    st.video('https://www.youtube.com/watch?v=5ZH2it92ZmA')


    # Sobre o autora
    st.title('{Me}')

    '''  
    /\ The Zen of Python /\ Me chamo Carol Braga, Publicitária e Pythonista também nas horas vagas com experiência na área de Marketing Digital. 
    Apaixonada por Data Science, Web Analytics, Análise de Dados e Dashboards. Formada em Marketing Digital e Especialização em Big Data pelo SENAC RJ. 
    Atualmente trabalho no Marketing do MetrôRio, participo como coautora na Jornada Colaborativa e no blog Data Hackers.

    Github: https://github.com/CarolBragaRJ
    
    Medium: https://medium.com/@carolbraga2
    
    Linkedin: https://www.linkedin.com/in/ana-carolina-braga-42ab2730/
     
    '''


#Página da análise
def analise_nexoanexo():
    st.title('Spotify + Python + Pearl Jam')

    file  = "data/pj-spotify-final5.csv"
    file2 = "data/pj-spotify-final5.csv"
    file3 = "data/pop-album3.csv"
    file4 = "data/pj-spotify-lets.csv"
    if file is not None:
        df = pd.read_csv(file)
        df2 = pd.read_csv(file2)
        df3 = pd.read_csv(file3)
        df4 = pd.read_csv(file4)

        aux = pd.DataFrame({"colunas": df.columns, 'tipos': df.dtypes})
        colunas_numericas = list(aux[aux['tipos'] != 'object']['colunas'])
        colunas_object = list(aux[aux['tipos'] == 'object']['colunas'])
        colunas = list(df.columns)

        #Menu Análises
        st.sidebar.header('Análises')
        menu_analises = st.sidebar.radio("", ('Visão geral', 'Álbuns',
                                         ))
        if menu_analises == 'Visão geral':
            visao_geral(df, df3, df4)

        if menu_analises == 'Álbuns':
            albuns(df)

def visao_geral(df,df3,df4):
    # Albúm Real Plug Mixtape
    rmx = df.query("nome_do_album == 'Vault 9: Live in Seattle 12/8/93' ")
    # Albúm Trap de Cria Mixtape
    tcm = df.query("nome_do_album == 'Lets Play Two' ")
    # Albúm Trap From Future
    tff = df.query("nome_do_album == 'Gigaton' ")
    tcc = df.query("nome_do_album == 'Pearl Jam (2017 Mix)' ")
    tpm = df.query("nome_do_album == 'Lightning Bolt' ")

    #Inf basicas
    st.header('**Os dados dos álbuns**')
    '''
    
    '''
    ''' 
    O dataset possui os dados de nove álbuns da banda e para o estudo é importante conhecer a quantidade total de músicas de cada álbum:
    '''

    ''' 
    Gigaton (2020): `12`

    Vault 9 Live in Seattle 12/8/93 (2019): `24`

    Pearl Jam 2006 (Mix 2017): `13`
    
    Lets Play Two (2017): `17`

    Lightning Bolt (2013): `12`

    Backspacer (2009): `12`

    Pearl Jam (2006): `13`

    Riot Act (2002): `15`

    Live MTV Unplugged (1992): `7`

    
    `Quantidade de músicas analisadas: 125`
    '''


    st.header("**O conjunto de dados**")

    ''' 
    O conjunto de dados da banda Pearl Jam foi coletado através da API do Spotify e não possui dados ausentes. 
    Os dados pode ser organizados em dataframes e exportados no formato .csv
    É possível navegar no dataset abaixo utilizando a rolagem sobre a imagem ou tocando e arrastando para o lado.
    
    '''
    st.write(df.style.set_properties(**{'background-color': 'black','color': 'lawngreen','border-color': 'white'}))

    '''
    '''


    st.header('**Análise da popularidade das músicas**')

    ''' 
    A média da popularidade das músicas do PJ no Spotify é 38.A primeira música mais popular é a Just Breathe do álbum Backspacer lançado em 2009. 
    Sirens pertence ao álbum Lightning Bolt de 2013 e Black faz parte do primeiro álbum da banda de 1991.
    Para visualizar os dados do gráfico passe o mouse ou toque nos pontos da imagem.
    
    '''

    dados = df[['nome_da_faixa', 'popularidade', 'nome_do_album']].sort_values(ascending=False, by='nome_da_faixa').reset_index(drop=True) #[:16]
    #fig = go.Figure(data=[
    #go.Bar(name='Confirmed', x=dados['nome_da_faixa'], y=dados['popularidade'])])
    ##st.plotly_chart(fig)  

    fig = px.scatter(df, x='popularidade', y='nome_da_faixa', color='popularidade', labels={'nome_da_faixa': 'músicas'})
    fig.update_yaxes(showticklabels=False)
    
    Chart(df).mark_circle(size=10).encode(
    #x = 'popularidade',
    #y = 'nome_da_faixa',
    #color = 'green'
    )

    st.plotly_chart(fig)

    '''
    
    '''

    st.header('**Análise da popularidade dos álbuns**')
    '''
    O álbum mais popular da banda foi lançado em 1992 nos estúdios da MTV em sua versão acústica. 
    MTV Unplugged foi uma série elaborada pela MTV que estreou em 1989, onde bandas e artistas tocavam suas músicas em versão acústica.
    Para visualizar os dados do gráfico passe o mouse ou toque nos pontos da imagem. 
    
    '''
    #graph_retweet(df)

    fig = px.bar(df3, x=df3['popularidade'], y=df3['nome_do_album'], labels={'nome_do_album': 'álbuns'}, color='popularidade')
    fig.update_yaxes(showticklabels=True)
    #fig.update_xaxes(tickvals =[30, 40, 60])

    st.plotly_chart(fig)

    st.header('**Relação das músicas com a média da Popularidade**') 
    #donut_explicita(df2)

    ''' 
    É possível visualizar que a média de popularidade das músicas está abaixo da média dos álbuns. 
    As músicas mais populares pertencem a álbuns antigos da banda, pois eles ficaram sete anos sem novos lançamentos o que provavelmente impactou os números.
    De acordo com alguns sites, a métrica do cálculo da popularidade do Spotify também é influenciada pela novidade e álbuns mais recentes terão maior pontuação.
    '''
    graph_retweet(df)


    '''
    
    '''





def albuns(df):
    st.sidebar.subheader('Álbuns')
    albuns = st.sidebar.radio("", ('Gigaton',
                                         'Vault 9: Live in Seattle 12/8/93',
                                         'Lets Play Two',
                                         'Pearl Jam (2017 Mix)',
                                         'Lightning Bolt',
                                         'Backspacer',
                                         'Pearl Jam',
                                         'Riot Act',
                                         'MTV Unplugged',
                                         ))
    '''
    A extração dos dados via API apresentou informações de nove álbuns da banda. O menu lateral permite navegar e analisar os dados dos álbuns coletados.
    '''

    if albuns == 'Gigaton':
        tff = df.query("nome_do_album == 'Gigaton' ")
        st.title('**Álbum Gigaton**')
        st.image('img/gigaton.jpg', width=400)
        
        '''
        '''
        ''' 
        Gigaton é o décimo primeiro albúm da banda Pearl Jam e foi lançado em março de 2020.

        "Quando o passado é o presente e o futuro não existe mais": banda escreve capítulo importante em sua história durante um dos períodos mais duros do planeta. https://www.tenhomaisdiscosqueamigos.com/2020/04/02/pearl-jam-resenha-gigaton/ 
        
        O álbum possui doze músicas que carregam o estilo da banda e surgiu em meio a pandemia do Coronavírus, shows foram cancelados por conta do isolamento social.
        As letras trazem uma mensagem de respeito ao planeta e a tudo o que nos cerca seguindo o genêro e estilo do grupo.
       
        '''

        st.subheader('**Comparativo da posição da música em relação a popularidade**')
        '''
        É possivel observar a popularidade das músicas em relação a posição da faixa no álbum. A música Retrograde é a mais popular e ocupa a décima primeira posição.
        A análise ajuda a concluir que a posição da faixa e a música não tem uma relação direta com a popularidade. 
        '''
        fig = px.bar(tff, x=tff['popularidade'], y=tff['nome_da_faixa'], color="posicao_da_faixa", labels={'nome_da_faixa': 'música','posicao_da_faixa': 'posição da faixa'})
        fig.update_layout(annotations=[{
        'text':'Retrograde é a música mais popular',
        'xref':'x', 
        'yref':'y', 
        'x':56, 
        'y':11,
        'showarrow':True,
        'ax': 0,
        'ay': -40,
        'font':dict(family="Calibri", size=11, color="#e67e22")}])

        st.plotly_chart(fig)

        st.subheader('**Músicas e a média da popularidade**')
        '''
        Todas as músicas do álbum Gigaton estão acima da média da popularidade das músicas coletadas dos demais álbuns da banda.
        
        '''
        fig = px.bar(tff, x=tff['popularidade'], y=tff['nome_da_faixa'], color="frequencia_de_popularidade_das_musicas", labels={'nome_da_faixa': 'música','frequencia_de_popularidade_das_musicas': 'popularidade das músicas','nome_do_album': 'álbum'})
        st.plotly_chart(fig)

    if albuns == 'Vault 9: Live in Seattle 12/8/93':
        rmx = df.query("nome_do_album == 'Vault 9: Live in Seattle 12/8/93'")
        st.title('**Álbum Vault 9: Live in Seattle 12/8/93**')
        st.image('img/vault-9.jpg', width=400)
        '''
        
        '''
        ''' 
        Em 13/12/19 lançou a coletânea Vault 9 sem anúncio prévio aos fãs. São faixas do show realizado na arena Mercer em Seattle.

        O show foi realizado em 08/12/93 quando começavam a fazer sucesso e o reconhecimento como banda grunge.
        
        As faixas abrangem músicas dos álbuns anteriores como "Alive", "Even Flow" e "Jeremy".
       
        '''

        st.subheader('**Comparativo da posição da música em relação a popularidade**')
        '''
        É possivel observar a popularidade das músicas em relação a posição da faixa no álbum. A música Even Flow é a mais popular e ocupa a segunda posição.
        Even Flow e Daughter são as músicas mais populares do álbum.
        '''
        dados2 = rmx[['nome_da_faixa', 'popularidade', 'nome_do_album']].sort_values(ascending=True, by='popularidade').reset_index(drop=True)

        fig = px.bar(dados2, x=dados2['popularidade'], y=dados2['nome_da_faixa'], color="popularidade", labels={'nome_da_faixa': 'música','posicao_da_faixa': 'posição da faixa'})
        #fig.update_yaxes(showticklabels=True)
        fig.update_layout(annotations=[{
        'text':'Even flow é a música mais popular',
        'xref':'x', 
        'yref':'y', 
        'x':52, 
        'y':23,
        'showarrow':True,
        'ax': 0,
        'ay': -40,
        'font':dict(family="Calibri", size=11, color="#e67e22")}])

        st.plotly_chart(fig)
        

        st.subheader('**Músicas e a média da popularidade**')
        '''
        Duas músicas do álbum Vault: 9 estão acima da média da popularidade das músicas coletadas dos demais álbuns da banda.
        
        '''
        fig = px.bar(rmx, x=rmx['popularidade'], y=rmx['nome_da_faixa'], color="frequencia_de_popularidade_das_musicas", labels={'nome_da_faixa': 'música','frequencia_de_popularidade_das_musicas': 'popularidade das músicas','nome_do_album': 'álbum'})
        st.plotly_chart(fig)

    if albuns == 'Lets Play Two':
        tcm = df.query("nome_do_album == 'Lets Play Two' ")
        st.title('**Álbum Lets Play Two**')
        st.image('img/letsplaytwo.jpg', width=400)
        '''

        '''
        ''' 
        Let's Play Two é um álbum ao vivo e um show da banda Pearl Jam. O álbum foi lançado em 29/09/17, com o filme do show sendo lançado em 17 de novembro de 2017. As filmagens e as músicas foram gravadas nos shows da banda no Wrigley Field durante sua turnê de 2016. (fonte Wikipédia e Adoro Cinema)

        Além da exibição do concerto o filme traz imagens exclusivas dos integrantes do grupo nos bastidores. (trailer vimeo: https://vimeo.com/233425502)
       
        '''

        st.subheader('**Comparativo da posição da música em relação a popularidade**')
        '''
        A média da popularidade das músicas do álbum é 36. A música Black é a mais popular e ocupa a sétima posição.
        A análise ajuda a concluir que a posição da faixa e a música não tem uma relação direta com a popularidade. 
        '''
        file4 = "data/pj-spotify-lets.csv"
        df5 = pd.read_csv(file4)
        df6 = df5[['nome_da_faixa', 'popularidade', 'nome_do_album', 'frequencia_de_popularidade_das_musicas']].sort_values(ascending=True, by='popularidade').reset_index(drop=True)

        fig = px.bar(df6, x='popularidade', y='nome_da_faixa', color="popularidade", labels={'nome_da_faixa': 'música'})
        fig.update_layout(annotations=[{
        'text':'Black é a música mais popular',
        'xref':'x', 
        'yref':'y', 
        'x':42, 
        'y':17,
        'showarrow':True,
        'ax': 0,
        'ay': -40,
        'font':dict(family="Calibri", size=11, color="#e67e22")}])

        st.plotly_chart(fig)


        st.subheader('**Músicas e a média da popularidade**')
        '''
        As músicas Black e Better Man estão acima da média da popularidade das músicas coletadas dos demais álbuns da banda.
        
        '''
        fig = px.bar(df5, x=df5['popularidade'], y=df5['nome_da_faixa'], color="frequencia_de_popularidade_das_musicas", labels={'nome_da_faixa': 'música','frequencia_de_popularidade_das_musicas': 'popularidade das músicas','nome_do_album': 'álbum'})
        st.plotly_chart(fig)

    if albuns == 'Pearl Jam (2017 Mix)':
        tcc = df.query("nome_do_album == 'Pearl Jam (2017 Mix)' ")
        st.title('**Álbum Pearl Jam (2017 Mix)**')
        st.image('img/pj2017.jpg', width=400)
        '''

        '''
        ''' 
        Pearl Jam foi o oitavo álbum da banda lançado em 02/05/06. Os dados a seguir pertencem a versão que foi remasterizada em 2017. 

        É considerado por boa parte da crítica como um álbum que remete aos tempos da cena grunge, no qual a banda alcançou grande sucesso e espaço na mídia pelos álbuns lançados entre 1991 e 1993.

        '''

        st.subheader('**Comparativo da posição da música em relação a popularidade**')
        '''
        A média da popularidade das músicas do álbum é 25. A música Come Back é a mais popular e ocupa a décima segunda posição.
        A análise ajuda a concluir que a posição da faixa e a música não tem uma relação direta com a popularidade. 
        '''
        file5 = "data/pj-spotify-2017.csv"
        df7 = pd.read_csv(file5)
        df8 = df7[['nome_da_faixa', 'popularidade', 'nome_do_album', 'frequencia_de_popularidade_das_musicas']].sort_values(ascending=True, by='popularidade').reset_index(drop=True)

        fig = px.bar(df8, x='popularidade', y='nome_da_faixa', color="popularidade", labels={'nome_da_faixa': 'música'})
        fig.update_layout(annotations=[{
        'text':'Come Back é a música mais popular',
        'xref':'x', 
        'yref':'y', 
        'x':28, 
        'y':13,
        'showarrow':True,
        'ax': 0,
        'ay': -40,
        'font':dict(family="Calibri", size=11, color="#e67e22")}])

        st.plotly_chart(fig)


        st.subheader('**Músicas e a média da popularidade**')
        '''
        A média da popularidade das músicas do álbum está abaixo das demais coletadas dos álbuns da banda.
        
        '''
        fig = px.bar(df7, x=df7['popularidade'], y=df7['nome_da_faixa'], color="frequencia_de_popularidade_das_musicas", labels={'nome_da_faixa': 'música','frequencia_de_popularidade_das_musicas': 'popularidade das músicas','nome_do_album': 'álbum'})
        st.plotly_chart(fig)

    if albuns == 'Lightning Bolt':
        tpm = df.query("nome_do_album == 'Lightning Bolt' ")
        st.title('**Álbum Lightning Bolt**')
        st.image('img/lightning-bolt.jpg', width=400)
        '''

        '''
        ''' 
        Lightning Bolt foi o décimo álbum de estúdio da banda lançado em 14/10/13. 

        O primeiro single, "Mind Your Manners," foi lançado em 11/07/13. "Lightning Bolt" segue Backspacer, de 2009.

        '''

        st.subheader('**Comparativo da posição da música em relação a popularidade**')
        '''
        As músicas Sirens e Future Days são as mais populares e ocupam, respectivamente, a quarta e última posição.
        A análise ajuda a concluir que a posição da faixa e a música não tem uma relação direta com a popularidade. 
        '''
        file6 = "data/pj-lightning-bolt.csv"
        df9 = pd.read_csv(file6)
        df10 = df9[['nome_da_faixa', 'popularidade', 'nome_do_album', 'frequencia_de_popularidade_das_musicas']].sort_values(ascending=True, by='popularidade').reset_index(drop=True)

        fig = px.bar(df10, x='popularidade', y='nome_da_faixa', color="popularidade", labels={'nome_da_faixa': 'música'})
        fig.update_layout(annotations=[{
        'text':'Sirens é a música mais popular',
        'xref':'x', 
        'yref':'y', 
        'x':63, 
        'y':12,
        'showarrow':True,
        'ax': 0,
        'ay': -40,
        'font':dict(family="Calibri", size=11, color="#e67e22")}])

        st.plotly_chart(fig)


        st.subheader('**Músicas e a média da popularidade**')
        '''
        A maior parte das músicas do álbum está acima da média da popularidade das músicas coletadas dos álbuns da banda.
        
        '''
        fig = px.bar(df9, x=df9['popularidade'], y=df9['nome_da_faixa'], color="frequencia_de_popularidade_das_musicas", labels={'nome_da_faixa': 'música','frequencia_de_popularidade_das_musicas': 'popularidade das músicas','nome_do_album': 'álbum'})
        st.plotly_chart(fig)

    if albuns == 'Backspacer':
        tpm = df.query("nome_do_album == 'Backspacer' ")
        st.title('**Álbum Backspacer**')
        st.image('img/backspacer.jpg', width=400)
        '''

        '''
        ''' 
        Backspacer foi o nono álbum da banda lançado em 18/09/09 na Europa e Oceania e em 21/09/09 nos EUA. 

        Em 1º de junho de 2009 a banda tocou pela primeira vez uma música do novo álbum, Got Some na estréia do programa Tonight Show with Conan O'Brien. Já em 20 de julho a banda lançou o primeiro single, The Fixer, e o disponibilizou em sua página oficial e em seu MySpace para ser ouvido.
        Fonte(Wikipédia)

        '''

        st.subheader('**Comparativo da posição da música em relação a popularidade**')
        '''
        A música Just Breathe é a música mais popular do álbum e ocupa a quinta posição.
        A análise ajuda a concluir que a posição da faixa e a música não tem uma relação direta com a popularidade. 
        '''
        file7 = "data/pj-backspacer.csv"
        df11 = pd.read_csv(file7)
        df12 = df11[['nome_da_faixa', 'popularidade', 'nome_do_album', 'frequencia_de_popularidade_das_musicas']].sort_values(ascending=True, by='popularidade').reset_index(drop=True)

        fig = px.bar(df12, x='popularidade', y='nome_da_faixa', color="popularidade", labels={'nome_da_faixa': 'música'})
        fig.update_layout(annotations=[{
        'text':'Just Breathe é a música mais popular',
        'xref':'x', 
        'yref':'y', 
        'x':69, 
        'y':12,
        'showarrow':True,
        'ax': 0,
        'ay': -40,
        'font':dict(family="Calibri", size=11, color="#e67e22")}])

        st.plotly_chart(fig)


        st.subheader('**Músicas e a média da popularidade**')
        '''
        O álbum possui mais da metade das músicas acima da média da popularidade das músicas coletadas dos álbuns da banda.
        
        '''
        fig = px.bar(df11, x=df11['popularidade'], y=df11['nome_da_faixa'], color="frequencia_de_popularidade_das_musicas", labels={'nome_da_faixa': 'música','frequencia_de_popularidade_das_musicas': 'popularidade das músicas','nome_do_album': 'álbum'})
        st.plotly_chart(fig)

    if albuns == 'Pearl Jam':
        tcc = df.query("nome_do_album == 'Pearl Jam' ")
        st.title('**Álbum Pearl Jam**')
        st.image('img/pj2017.jpg', width=400)
        '''

        '''
        ''' 
        Pearl Jam foi o oitavo álbum da banda lançado em 02/05/06, em 2017 ele foi remasterizado.

        Os dados abaixo pertencem ao álbum lançado em 2006. As músicas Come Back e World Wide Suicide permaneceram como as mais populares nos dois álbuns.

        '''

        st.subheader('**Comparativo da posição da música em relação a popularidade**')
        '''
        A média da popularidade das músicas do álbum é 38. A música Come Back é a mais popular e ocupa a décima segunda posição.
        A análise ajuda a concluir que a posição da faixa e a música não tem uma relação direta com a popularidade. 
        '''
        file5 = "data/pj-pearl-jam.csv"
        df7 = pd.read_csv(file5)
        df8 = df7[['nome_da_faixa', 'popularidade', 'nome_do_album', 'frequencia_de_popularidade_das_musicas']].sort_values(ascending=True, by='popularidade').reset_index(drop=True)

        fig = px.bar(df8, x='popularidade', y='nome_da_faixa', color="popularidade", labels={'nome_da_faixa': 'música'})
        fig.update_layout(annotations=[{
        'text':'Come Back é a música mais popular',
        'xref':'x', 
        'yref':'y', 
        'x':56, 
        'y':13,
        'showarrow':True,
        'ax': 0,
        'ay': -40,
        'font':dict(family="Calibri", size=11, color="#e67e22")}])

        st.plotly_chart(fig)


        st.subheader('**Músicas e a média da popularidade**')
        '''
        A média da popularidade das músicas do álbum está abaixo das demais coletadas dos álbuns da banda.
        
        '''
        fig = px.bar(df7, x=df7['popularidade'], y=df7['nome_da_faixa'], color="frequencia_de_popularidade_das_musicas", labels={'nome_da_faixa': 'música','frequencia_de_popularidade_das_musicas': 'popularidade das músicas','nome_do_album': 'álbum'})
        st.plotly_chart(fig)

    if albuns == 'Riot Act':
        tcc = df.query("nome_do_album == 'Riot Act' ")
        st.title('**Álbum Riot Act**')
        st.image('img/riot-act.jpg', width=400)
        '''

        '''
        ''' 
        Riot Act foi o sétimo álbum da banda lançado em 12/11/02.

        Após uma turnê completa em apoio ao álbum anterior, Binaural (2000), o Pearl Jam fez uma pausa de um ano. 
        A banda se reuniu novamente no início de 2002 e começou a trabalhar em um novo álbum. A música do álbum era diversa, incluindo canções influenciadas pelo folk , art rock e rock experimental. 
        As letras tratam da mortalidade e do existencialismo, com influência tanto do clima político após os ataques terroristas de 11 de setembro de 2001
        e a morte acidental de nove fãs durante a apresentação do Pearl Jam no Festival Roskilde de 2000. (Fonte: Wikipédia)

        '''

        st.subheader('**Comparativo da posição da música em relação a popularidade**')
        '''
        A música I Am Mine é a mais popular e ocupa a sexta posição.
        A análise ajuda a concluir que a posição da faixa e a música não tem uma relação direta com a popularidade. 
        '''
        file6 = "data/pj-riot-act.csv"
        df13 = pd.read_csv(file6)
        df14 = df13[['nome_da_faixa', 'popularidade', 'nome_do_album', 'frequencia_de_popularidade_das_musicas']].sort_values(ascending=True, by='popularidade').reset_index(drop=True)

        fig = px.bar(df14, x='popularidade', y='nome_da_faixa', color="popularidade", labels={'nome_da_faixa': 'música'})
        fig.update_layout(annotations=[{
        'text':'I Am Mine é a música mais popular',
        'xref':'x', 
        'yref':'y', 
        'x':59, 
        'y':15,
        'showarrow':True,
        'ax': 0,
        'ay': -40,
        'font':dict(family="Calibri", size=11, color="#e67e22")}])

        st.plotly_chart(fig)


        st.subheader('**Músicas e a média da popularidade**')
        '''
        A média da popularidade das músicas do álbum está abaixo das demais coletadas dos álbuns da banda.
        
        '''
        fig = px.bar(df13, x=df13['popularidade'], y=df13['nome_da_faixa'], color="frequencia_de_popularidade_das_musicas", labels={'nome_da_faixa': 'música','frequencia_de_popularidade_das_musicas': 'popularidade das músicas','nome_do_album': 'álbum'})
        st.plotly_chart(fig)

    if albuns == 'MTV Unplugged':
        tcc = df.query("nome_do_album == 'MTV Unplugged' ")
        st.title('**Álbum MTV Unplugged**')
        st.image('img/mtv-pj.jpg', width=400)
        '''

        '''
        ''' 
        Para celebrar o 30º aniversário do primeiro show da carreira, o Pearl Jam lançou pela primeira vez no streaming o show icônico do MTV Unplugged (via NME).

        A banda gravou a sessão Unplugged em 16 de março de 1992. Nela, apresentaram versões acústicas das músicas do disco Ten, como "State of Love".
        (Fonte: https://rollingstone.uol.com.br/noticia/iconica-apresentacao-de-pearl-jam-no-mtv-unplugged-agora-esta-disponivel/)

        '''

        st.subheader('**Comparativo da posição da música em relação a popularidade**')
        '''
        A música Black é a mais popular e ocupa a sexta posição.
        A análise ajuda a concluir que a posição da faixa e a música não tem uma relação direta com a popularidade. 
        '''
        file6 = "data/pj-mtv.csv"
        df13 = pd.read_csv(file6)
        df14 = df13[['nome_da_faixa', 'popularidade', 'nome_do_album', 'frequencia_de_popularidade_das_musicas']].sort_values(ascending=True, by='popularidade').reset_index(drop=True)

        fig = px.bar(df14, x='popularidade', y='nome_da_faixa', color="popularidade", labels={'nome_da_faixa': 'música'})
        fig.update_layout(annotations=[{
        'text':'Black é a música mais popular',
        'xref':'x', 
        'yref':'y', 
        'x':62, 
        'y':7,
        'showarrow':True,
        'ax': 0,
        'ay': -40,
        'font':dict(family="Calibri", size=11, color="#e67e22")}])

        st.plotly_chart(fig)


        st.subheader('**Músicas e a média da popularidade**')
        '''
        As músicas do álbum estão acima da média da popularidade das demais coletadas dos álbuns da banda.
        
        '''
        fig = px.bar(df13, x=df13['popularidade'], y=df13['nome_da_faixa'], color="frequencia_de_popularidade_das_musicas", labels={'nome_da_faixa': 'música','frequencia_de_popularidade_das_musicas': 'popularidade das músicas','nome_do_album': 'álbum'})
        st.plotly_chart(fig)


def graph_retweet(df):

    #Agrupamento dos dados
    df_retweet = Counter(df.frequencia_de_popularidade_das_musicas)
    labels = list(df_retweet.keys())
    values = list(df_retweet.values())

    #Plot
    data=[go.Pie(labels=labels, values=values, hole=.5, marker = {'colors': ['#B5ACA7', '#310d75']})]
    st.plotly_chart(data)

def donut_explicita(df2):

    #Agrupamento dos dados
    df_retweet = Counter(df2.musica_explicita)
    labels = list(df_retweet.keys())
    values = list(df_retweet.values())

    #Plot
    data=[go.Pie(labels=labels, values=values, hole=.5, marker = {'colors': ['#B5ACA7', '#0000B3']})]
    st.plotly_chart(data)




menu()


