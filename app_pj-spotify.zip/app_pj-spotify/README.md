# Aplicacao_NexoAnexo
Aplicação ou Dashboard desenvolvido para o meu projeto de análise de dados dos álbuns do artista NexoAnexo.
